import 'package:castle_weather/models/weather_model.dart';
import 'package:castle_weather/screens/search_page.dart';
import 'package:castle_weather/widgets/weather_card.dart';
import 'package:flutter/material.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  @override
  Widget build(BuildContext context) {
    final weatherModel = WeatherModel(
      cityName: 'Астана',
      temperature: -10,
      description: 'ясно',
      icon: '01d',
      humidity: 77,
      windSpeed: 2.2,
    );

    return Scaffold(
      body: AnimatedContainer(
        duration: Duration(milliseconds: 500),
        child: Center(child: WeatherCard(weatherModel: weatherModel)),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.of(context).push(_createRoute());
        },
        child: Icon(Icons.search),
      ),
    );
  }

  Route _createRoute() {
    return PageRouteBuilder(
      transitionsBuilder: (context, animation, secAnimation, child) {
        final slide = Tween(
          begin: Offset(1, 0),
          end: Offset(0, 0),
        ).animate(animation);

        return SlideTransition(position: slide, child: child);
      },

      pageBuilder: (context, animation, secAnimation) {
        return SearchPage();
      },
    );
  }
}
